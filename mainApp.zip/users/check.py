import requests

def check(request):
    API_KEY = '<ldV8hQWqg_T4nVbOlAab97t1F122_Zn-yWIVFHZZ>'

    response = requests.get(
        url="https://api.predicthq.com/v1/events/",
        headers={
        "Authorization": f"Bearer {ldV8hQWqg_T4nVbOlAab97t1F122_Zn-yWIVFHZZ}",
        "Accept": "application/json"
        },
        params={
        "category": "public-holidays,festivals,concerts",
        "start.gte": "2022-12-02", # 시작 날짜 
        "country": "JP" # 22 country_code 를 검색 parameter 로 사용
        }
    )

    print(response.json()['results'])